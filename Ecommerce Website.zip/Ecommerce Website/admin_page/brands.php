<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customer Website</title>
  <link rel="stylesheet" href="brands.css">
</head>

<body>
  <nav class="nav1">
    <img src="../img/images.png" alt="image" class="logo">
  </nav>

  <nav class="nav2">
    <ul>
      <li>Welcome Admin</li>
    </ul>
  </nav>

  <ul>
    <button class="btn1"><a href="products.php" class="options">Insert Products</a></button>
    <button class="btn1">View Products</button>
    <button class="btn1"><a href="cart.php" class="options">Insert Categories</a></button>
    <button class="btn1">View Categories</button>
    <button class="btn1"><a href="brands.php" class="options">Insert Brands</a></button>
    <button class="btn1">View Brands</button>
    <button class="btn1">All Orders</button>
    <button class="btn1">All Payments</button>
    <button class="btn1">All user_info</button>
    <button class="btn1"><a href="../logins/login.php" class="options">Logout</a></button>
  </ul>

  <form method="POST" action="brands.php" class="brand-form">

      <label for="brand_title">Brand Title:</label>
      <input type="text" name="brand_title" id="brand_title" class="search" placeholder="Enter Brand" required>
      <label for="categories_title">Category Title:</label>
      <input type="text" name="categories_title" id="categories_title" class="search" placeholder="Enter Category" required>
      <label for="quantity">Quantity:</label>
      <input type="number" name="quantity" id="quantity" class="search" placeholder="Enter Quantity" required>
      <label for="product_price">Product Price:</label>
      <input type="number" name="product_price" id="product_price" class="search" placeholder="Enter Price" required>
      <input type="submit" class="btn2" value="Add Brand">
  </form>

  <div class="list">
    <h3>Brand Details</h3>
    <?php
    // Include your database connection file
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "my store";

    $connection = mysqli_connect($host, $username, $password, $database);

    if (!$connection) {
      die("Connection Error: " . mysqli_connect_error());
    }

    $selectQuery = "SELECT brand_title, categories_title, quantity, product_price FROM brands";
    $result = mysqli_query($connection, $selectQuery);

    if (mysqli_num_rows($result) > 0) {
      echo "<table>";
      echo "<tr><th>Brand Title</th><th>Category Title</th><th>Quantity</th><th>Product Price</th></tr>";
      while ($row = mysqli_fetch_assoc($result)) {
         echo "<tr>";
        echo "<td>" . htmlspecialchars($row["brand_title"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["categories_title"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["quantity"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["product_price"]) . "</td>";
        echo "</tr>";
      }
      echo "</table>";
    } else {
      echo "No brands found.";
    }

    mysqli_close($connection);
    ?>
  </div>

  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $brand_title = $_POST["brand_title"];
    $categories_title = $_POST["categories_title"];
    $quantity = $_POST["quantity"];
    $product_price = $_POST["product_price"];

    // Include your database connection file
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "my store";

    $connection = mysqli_connect($host, $username, $password, $database);

    if (!$connection) {
      die("Connection Error: " . mysqli_connect_error());
    }

    $checkQuery = "SELECT brand_title FROM brands WHERE brand_title = ?";
    $checkStmt = mysqli_prepare($connection, $checkQuery);
    mysqli_stmt_bind_param($checkStmt, "s", $brand_title);
    mysqli_stmt_execute($checkStmt);
    mysqli_stmt_store_result($checkStmt);

      $insertQuery = "INSERT INTO brands (brand_title, categories_title, quantity, product_price) VALUES (?, ?, ?, ?)";
      $stmt = mysqli_prepare($connection, $insertQuery);
      mysqli_stmt_bind_param($stmt, "ssdd", $brand_title, $categories_title, $quantity, $product_price);

      if (mysqli_stmt_execute($stmt)) {
        $inserted_id = mysqli_insert_id($connection);
        echo "<script>alert('Brand added successfully!');</script>";
      } else {
        echo "Error: " . mysqli_error($connection);
      }
    }

    mysqli_close($connection);
  ?>
</body>
</html>

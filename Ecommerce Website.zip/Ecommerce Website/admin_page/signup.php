<html>

   <head>
       <title>customer Website</title>
          <link rel="stylesheet" href="signup.css">
   </head>            

 <body background="images/background.jpeg"> 
  <nav class="nav1">
  <img src="../img/images.png" alt="image" class="logo"> 
  </nav>  
  <form method="post" action="signup.php" class="form">
    <h1> SIGN UP </h1>
        <input type="text" name="name" placeholder="enter your name" id="name" class="text_from" required><br><br>
        <input type="email" name="email"placeholder="enter youremail " id="email" class="text_from" required> <br><br>
        <input type="tel" name="phone"placeholder="enter your mobile number" id="phone" class="text_from"required> <br><br>
        <input type="password" name="password"placeholder="enter your password" id="password" class="text_from" max="25" required><br><br>
        <input type="password" name="password2"placeholder="enter your confirm password" id="password2" class="text_from" required><br><br>
        <button type="submit" class="btn1"> SUBMIT </button>    
    </form>

    </body>
    </html>


<?php
    session_start();

    error_reporting(E_ALL);
    ini_set('display_errors', '1');


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $contact = $_POST["phone"];
        $userPassword = $_POST["password"];
        $userPassword2 = $_POST["password2"];
        
        // Check if password and password2 match
        if ($userPassword !== $userPassword2) {
            // Passwords do not match, display an alert using JavaScript
            echo "<script>alert('Passwords do not match.');</script>";
        } else {
            // Establish a database connection
            $host = "localhost";
            $user = "root";
            $db_password = "";
            $database = "login_register"; 
            
            $connection = mysqli_connect($host, $user, $db_password, $database);
            
            if (!$connection) {
                die("Connection Error: " . mysqli_connect_error());
            }
            
            // Use prepared statement to check if the email already exists in 'data' table
            $checkEmailQuery = "SELECT ID FROM admindata WHERE email = ?";
            $stmt = mysqli_prepare($connection, $checkEmailQuery);
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if ($result && mysqli_num_rows($result) > 0) {
                // Email already exists, display an alert using JavaScript
                echo "<script>alert('Signup failed. Email already in use.');</script>";
            } else {
                // Email is unique, proceed with registration
                // Hash the password
                $hashedPassword = password_hash($userPassword, PASSWORD_DEFAULT);
                
                // Use prepared statement to insert data into 'user_info' table
                $insertDataQuery = "INSERT INTO admindata (name, email, contact, password) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($connection, $insertDataQuery);
                mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $contact, $hashedPassword);
                $registrationResult = mysqli_stmt_execute($stmt);   
                
                if ($registrationResult) {
                    // Registration successful, redirect the user to welcome.php
                    header("Location: admin.php");
                    exit();
                } else {
                    // Registration failed, handle the error
                    echo "<script>alert('Signup failed: " . mysqli_error($connection) . "');</script>";
                }
            }
            mysqli_close($connection);
        }
    }
    ?>



<html>
  <head>
       <title>customer Website</title>
          <link rel="stylesheet" href="cart.css">
  </head>            

  <body> 
    <nav class="nav1">
      <img src="../img/images.png" alt="image" class="logo"> 
    
    </nav>

    <nav class="nav2">
      <ul>
        <li>Welcome Admin</li>
      </ul>
    </nav>

    <ul>
    <button class="btn1"><a href="products.php" class="options">Insert Products</a></button></button>
      <button class="btn1">View Products</button>
      <button class="btn1"><a href="cart.php" class="options">Insert Categories</a></button></button>
      <button class="btn1">View Categories</button>
      <button class="btn1"><a href="brands.php" class="options">Insert Brands</a></button>
      <button class="btn1">View Brands</button>
      <button class="btn1">All Orders</button>
      <button class="btn1">All Payments</button>
      <button class="btn1">All user_info</button>
      <button class="btn1"><a href="../logins/login.php" class="options">Logout</a></button>
    </ul>

    <form method="POST" action="brands.php" >
        <div class="nav_right">
          <input type="text" name="brand_title" class="search" placeholder="Enter Brand" id="brands_title" required>
          <input type="submit" class="btn2" value="Add brand">
        </div>

        <div class="list">
        <h3>Category Titles</h3>
            <?php
          // Database connection parameters
          $host = "localhost"; // Your database host
          $username = "root"; // Your database username
          $password = ""; // Your database password
          $database = "my store"; // Your database name
          
          // Create a database connection
          $connection = mysqli_connect($host, $username, $password, $database);
          
          // Check if the connection was successful
          if (!$connection) {
              die("Connection Error: " . mysqli_connect_error());
          }
          
          // Retrieve category titles from the database
          $selectQuery = "SELECT category_title FROM categories";
          $result = mysqli_query($connection, $selectQuery);
          
          // Check if any categories were found
          if (mysqli_num_rows($result) > 0) {
              echo "<ul>";
              while ($row = mysqli_fetch_assoc($result)) {
                  echo "<li>" . $row["category_title"] . "</li>";  
              } 
              echo "</ul>";
          } else {
              echo "No categories found.";
          }
          
          // Close the database connection
          mysqli_close($connection);
          ?>
    </div>
  </body>
</html>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the brands title from the form
    $brands_title = $_POST["brand_title"];

    // Database connection parameters
    $host = "localhost"; // Your database host
    $username = "root"; // Your database username
    $password = ""; // Your database password
    $database = "my store"; // Your database name

    // Create a database connection
    $connection = mysqli_connect($host, $username, $password, $database);

    // Check if the connection was successful
    if (!$connection) {
        die("Connection Error: " . mysqli_connect_error());
    }

    // Check if the brands title already exists in the database
    $checkQuery = "SELECT brand_title FROM brands WHERE brand_title = ?";
    $checkStmt = mysqli_prepare($connection, $checkQuery);
    mysqli_stmt_bind_param($checkStmt, "s", $brands_title);
    mysqli_stmt_execute($checkStmt);
    mysqli_stmt_store_result($checkStmt);

    // If the brands title already exists, display an error message
    if (mysqli_stmt_num_rows($checkStmt) > 0) {
        echo "<script>alert('brand already exists in the database.');</script>";
    } else {
        // Prepare and execute an SQL query to insert the brands title into the database
        $insertQuery = "INSERT INTO brands (brand_title) VALUES (?)";
        $stmt = mysqli_prepare($connection, $insertQuery);
        mysqli_stmt_bind_param($stmt, "s", $brands_title);

        if (mysqli_stmt_execute($stmt)) {
            $inserted_id = mysqli_insert_id($connection); // Get the auto-incremented ID
            echo "<script>alert('brand added successfully!');</script>";
        } else {
            echo "Error: " . mysqli_error($connection);
        }
    }

    // Close the database connection
    mysqli_close($connection);
}
?>

<html>

   <head>
       <title>customer Website</title>
          <link rel="stylesheet" href="admin.css">
   </head>            

 <body> 
  <nav class="nav1">
  <img src="../img/images.png" alt="image" class="logo"> 
    
</nav>

<nav class="nav2">
<ul>
  <li>Welcome Admin</li>
</ul>
</nav>

 <ul>
      <button class="btn1"><a href="products.php" class="options">Insert Products</a></button></button>
      <button class="btn1"><a href="products.php" class="options">View Products</a></button>
      <button class="btn1"><a href="cart.php" class="options">Insert Categories</a></button></button>
      <button class="btn1"><a href="products.php" class="options">View Categories</a></button>
      <button class="btn1"><a href="brands.php" class="options">Insert Brands</a></button>
      <button class="btn1"><a href="products.php" class="options">View Brands</a></button>
      <button class="btn1"><a href="products.php" class="options">All Orders</a></button>
      <button class="btn1"><a href="products.php" class="options">All Payments</a></button>
      <button class="btn1"><a href="products.php" class="options">All user_info</a></button>
      <button class="btn1"><a href="../logins/login.php" class="options">Logout</a></button>
   </ul>

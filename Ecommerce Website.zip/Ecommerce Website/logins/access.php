<html>

   <head>
       <title>customer Website</title>
          <link rel="stylesheet" href="access.css">
   </head>            

 <body> 
  <nav class="nav1">
  <img src="../img/images.png" alt="image" class="logo"> 
     <ul>
      <li><a href="../index.php">Home</a></li>
      <li><a href="">Products</a></li>
      <li><a href="">Register</a></li>
      <li><a href="">Contact</a> </li>
      <li><a href="cart.php">cart</a></li>
      <li><a href="">Total Price:100/-</a></li>
      <div class="nav_right">  
        <input type="text" class="search" placeholder="Search here">  
        <button class="btn1"> Search </button>
      </div>  
    </ul>
  </nav>  

<nav class="nav2">
<ul>
  <li>Welcome User </li>
  <button class="btn4"><a href="../index.php" class="options">Logout</a></button> 
</ul>
</nav>

<div class="carts">
   <div class="cart1">
    <img src="../img/1.jpg" alt="image" class="img1"><br><br>
     &nbsp;<sup>₹</sup>749/-<br>
    <p1> Ptron Earbuds </p1><br>
    <p2>Bluetooth5.3 Wireless Earbuds with Charging Case </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart1">
    <img src="../img/2.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1>Portronics Ruffpad </p1><br>
    <p2>Re-Writable Writting Pad with Screen 8.5inch for Drawing and Many More</p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>  
   
   <div class="cart1">
    <img src="../img/3.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Acer Aspire Lite </p1><br>
    <p2> Intel Core i3 (8GB RAM/512GB SSD/Windows 11), 15.6"inch Display<p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart1">
    <img src="../img/4.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1>Portronics Ruffpad </p1><br>
    <p2>Re-Writable LCD Writting Pad with Screen 21.5cm (8.5-inch) for Drawing, Playing and Many More</p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>  

</div>

<div class="cart3">

   <div class="cart2">
    <img src="../img/5.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/6.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>  
   
   <div class="cart2">
    <img src="../img/7.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/8.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>
   
</div>

<div class="cart3">

   <div class="cart2">
    <img src="../img/5.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/6.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>  
   
   <div class="cart2">
    <img src="../img/7.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/8.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>
   
</div>

<div class="cart3">

   <div class="cart2">
    <img src="../img/5.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/6.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>  
   
   <div class="cart2">
    <img src="../img/7.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>

   <div class="cart2">
    <img src="../img/8.jpg" alt="image" class="img1"><br><br>
    &nbsp;<sup>₹</sup>749/- <br>
    <p1> Card Title </p1><br>
    <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
    <button class="btn2"> Add to cart  </button>  
    <button class="btn3"> View More </button>  
   </div>
   
</div>

</body> 
</html>

<?php
// Start the session (if not already started)
session_start();

// Check if the product_name and price are sent via POST
if (isset($_POST['product_name']) && isset($_POST['price'])) {
    // Create a new item array
    $item = array(
        'product_name' => $_POST['product_name'],
        'price' => $_POST['price']
    );

    // Check if the cart session variable is set
    if (!isset($_SESSION['cart'])) {
        // If not, create an empty array
        $_SESSION['cart'] = array();
    }

    // Add the new item to the cart
    $_SESSION['cart'][] = $item;
}

// Redirect back to the index page
header('Location: cart.php'); 
exit();
?>

<html>

<head>
    <title> Login </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
     integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="login.css">
</head>            

<body background="images/background.jpeg">
<nav class="nav1">
        <ul>
        <img src="../img/images.png" alt="image" class="logo"> 
        <div class="nav_right">
        <button onclick="window.location.href='access.php'"class="btn1">Home</button>
        <button onclick="window.location.href='signup.php'" class="btn1"> SIGN UP </button>  
        </div>
        </ul>
    </nav>

    <form method="post" action="login.php" class="form">
      <h2> Login to Shop More </h2> <br>
      <div class="info">
          <input type="email" name="email" id="email" placeholder="Enter your email"class="text_from" required><br><br><br>  
          <input type="password" name="password" id="password" placeholder="Enter your password" max="25"class="text_from" required >
          <br><br> <h6>By continuing, you agree to Amazon's Conditions of Use and Privacy Notice.</h6>
          <button type="submit" class="btn2"> Log In </button><br>
          <br><h5>----Contact Us On----</h5>
          <br><h2><i class="fa-brands fa-whatsapp" style="color: #002d7a;"></i>&nbsp;&nbsp;<i class="fa-brands fa-facebook" style="color: #002d7a;"></i>&nbsp;&nbsp;<i class="fa-brands fa-instagram" style="color: #002d7a;"></i></h2>
          <h2>
          
      </div>    
    </form> 


</body>
</html>


<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $userPassword = $_POST["password"];

    // Establish a database connection
    $host = "localhost";
    $user = "root";
    $db_password = "";
    $database = "login_register";

    $connection = mysqli_connect($host, $user, $db_password, $database);

    if (!$connection) {
        die("Connection Error: " . mysqli_connect_error());
    }

    // Check if the email exists in 'data' table
    $checkEmailQuery = "SELECT ID, password FROM users WHERE email = ?";
    $stmt = mysqli_prepare($connection, $checkEmailQuery);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        // Email exists, verify the password
        $row = mysqli_fetch_assoc($result);
        $storedPassword = $row['password'];

        if (password_verify($userPassword, $storedPassword)) {
            // Passwords match, check for a specific email
            if ($email === "admin01@mail.com") {
                // The user is allowed to access the admin page
                $_SESSION["user_id"] = $row['ID'];
                header("Location: ../admin_page/admin.php");
                exit();
            } else {
              // Passwords match, log the user in
            $_SESSION["user_id"] = $row['ID'];
            // Redirect the user to the "access.php" page
            header("Location: ../logins/access.php");
            exit();
            }
        } else {
            // Password is incorrect, display an alert
            echo "<script>alert('Login failed. Incorrect password.');</script>";
        }
   } else {
        // Email doesn't exist, display an alert
        echo "<script>alert('Login failed. Email not found.');</script>";
    }
    mysqli_close($connection);
}
?>
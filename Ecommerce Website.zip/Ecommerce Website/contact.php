<html>
<head>
   
    <title>Customer Website</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
     integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="contact.css">
</head>
<body>

<nav class="nav1">
    <img src="./img/images.png" alt="image" class="logo">
    <ul>
    
    <li><a href="access.php">Contact</a> </li>
        
    </ul>
</nav>

<nav class="nav2">
    <ul>
    <li><a href="access.php">Home</a> </li>
    ><li><a href="contact.php"> Contact</a> </li>
   
       
    </ul>
</nav>

<div class="info">
          ----Contact Us On---- 
           <h2 class="logos"><a href="https://web.whatsapp.com/"><i class="fa-brands fa-whatsapp" style="color: #8484ff;"></i></a>&nbsp;&nbsp;<a href="https://www.facebook.com/"><i class="fa-brands fa-facebook" style="color: #8484ff;"></i></a>&nbsp;&nbsp;<a href="https://www.instagram.com/"><i class="fa-brands fa-instagram" style="color: #8484ff;"></i></a></h2>

         
          
</div>

<form method="POST" action="brands.php" >
        <div class="nav_right">
          <input type="text" name="Qurey" class="search" placeholder="Ask Me" required>
          <input type="submit" class="btn2" value="ask">
        </div>

        
<?php
// Start session to store cart data
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to add an item to the cart and save to the database
function addToCart($productId, $productName, $productPrice) {
    global $conn;

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Check if the product is already in the cart
    $index = array_search($productId, array_column($_SESSION['cart'], 'id'));

    if ($index !== false) {
        // Product is already in the cart, update quantity or do something else
        $_SESSION['cart'][$index]['quantity'] += 1;
    } else {
        // Product is not in the cart, add it
        $_SESSION['cart'][] = [
            'id' => $productId,
            'name' => $productName,
            'price' => $productPrice,
            'quantity' => 1,
        ];

        // Save to the database
        $sql = "INSERT INTO cart (product_id, product_name, product_price, quantity)
                VALUES ('$productId', '$productName', '$productPrice', 1)";

        if ($conn->query($sql) === false) {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Example: Add a product to the cart
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $productId = $_GET['id'];
    $productName = 'Product ' . $productId;
    $productPrice = 749; // Replace with the actual price

    addToCart($productId, $productName, $productPrice);
}
?>

<html>
<head>
   
    <title>Customer Website</title>
    <link rel="stylesheet" href="access.css">
</head>
<body>

<nav class="nav1">
    <img src="./img/images.png" alt="image" class="logo">
    <ul>
        <li><a href="../access.php">Home</a></li>
        <li><a href="">Products</a></li>
        <li><a href=".\logins\login.php">Register</a></li>
        <li><a href="contact.php">Contact</a> </li>
        <div class="nav_right">
            <form method="post" action="">
                <input type="text" class="search" name="search" placeholder="Search here">
                <button type="submit" name="search_btn" class="btn1"> Search </button>
            </form>
        </div>
    </ul>
</nav>

<nav class="nav2">
    <ul>
        <li><a href="logins\signup.php">Sign Up</a></li>
        <li><a href=".\logins\login.php">Login</a></li>
        <div class="nav_right">
            <ul>
                <li><a href="admin_page\login.php">Admin</a></li>
            </ul>
        </div>
    </ul>
</nav>

<div class="carts">
    <!-- Your product cards with "Add to Cart" buttons -->

    <div class="cart1">
        <img src="./img/1.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Ptron Earbuds </p1><br>
        <p2>Bluetooth5.3 Wireless Earbuds with Charging Case </p2><br>
        <form method="post" action="?action=add&id=1">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/2.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Portronics Ruffpad </p1><br>
        <p2>Re-Writable Writting Pad with Screen 8.5inch for Drawing and Many More</p2><br>
        <form method="post" action="?action=add&id=2">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/3.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Acer Aspire Lite </p1><br>
        <p2> Intel Core i3 (8GB RAM/512GB SSD/Windows 11), 15.6"inch Display</p2><br>
        <form method="post" action="?action=add&id=3">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/4.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Portronics Ruffpad </p1><br>
        <p2>Re-Writable LCD Writting Pad with Screen 21.5cm (8.5-inch) for Drawing, Playing and Many More</p2><br>
        <form method="post" action="?action=add&id=4">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <!-- Add more product cards as needed -->

</div>

<div class="cart3">
    <!-- Your additional product cards with "Add to Cart" buttons -->

    <div class="cart1">
        <img src="./img/5.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Card Title </p1><br>
        <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
        <form method="post" action="?action=add&id=5">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/6.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Card Title </p1><br>
        <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
        <form method="post" action="?action=add&id=6">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/7.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Card Title </p1><br>
        <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
        <form method="post" action="?action=add&id=7">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <div class="cart1">
        <img src="./img/8.jpg" alt="image" class="img1"><br><br>
        &nbsp;<sup>₹</sup>749/-<br>
        <p1> Card Title </p1><br>
        <p2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti debitis ea eaque dicta, rem assumenda.  </p2><br>
        <form method="post" action="?action=add&id=8">
            <button type="submit" class="btn2"> Add to cart  </button>
        </form>
        <form method="post" action="view_more.php">
            <button type="submit" class="btn3"> View More </button>
        </form>
    </div>

    <!-- Add more product cards as needed -->

</div>

<div class="regi">
    <button onclick="window.location.href='./logins/login.php'" class="btn5"> Register to view more </button>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
